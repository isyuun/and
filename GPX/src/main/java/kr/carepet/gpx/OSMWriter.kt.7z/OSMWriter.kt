/*
 *  Copyright 2011 The Android Open Source Project
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *
 * Copyright (c) 2023. CarePat All right reserved.
 * This software is the proprietary information of CarePet Co.,Ltd.
 *
 *  Revision History
 *  Author                         Date          Description
 *  --------------------------     ----------    ----------------------------------------
 *  isyuun@care-pet.kr             2023. 9. 13.   description...
 */

package kr.carepet.gpx

/**
 * @Project     : carepet-android
 * @FileName    : OSMWriter.kt
 * @Date        : 2023. 09. 13.
 * @author      : isyuun@care-pet.kr
 * @description :
 */
import android.location.Location
import org.osmdroid.views.overlay.gpx.GPXFile
import org.osmdroid.views.overlay.gpx.GPXRoute
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class OSMWriter : _GPXWriter() {
    companion object {
        fun write(locations: List<Location>, file: File) {
            if (locations.isEmpty()) {
                return
            }

            val data = GPXFile()
            val route = GPXRoute()

            val dateFormat = SimpleDateFormat(GPX_SIMPLE_DATE_FORMAT, Locale.US)
            val currentTime = dateFormat.format(Date(locations.first().time))

            route.name = currentTime

            data.version = GPX_VERSION
            data.creator = GPX_CREATOR

            data.addNamespace("xsi", GPX_XSI_NAMESPACE)

            val comments = """
                <!-- Created with CarePet -->
                <!-- Track $currentTime = ${locations.size} TrackPoints + 0 Placemarks -->
                <!-- Track Statistics (based on Total Time | Time in Movement): -->
                <!-- Distance = ${calculateTotalDistance(locations)} -->
                <!-- Duration = ${calculateDuration(locations)} | N/A -->
                <!-- Altitude Gap = ${calculateMaxAltitudeGap(locations)} -->
                <!-- Max Speed = ${calculateMaxSpeed(locations)} m/s -->
                <!-- Avg Speed = ${calculateAvgSpeed(locations)} m/s -->
                <!-- Direction = N/A -->
                <!-- Activity = N/A -->
                <!-- Altitudes = N/A -->
            """.trimIndent()

            data.addComment(comments)

            val metadata = data.metadata
            metadata?.name = "GPS Logger $currentTime"
            metadata?.time = currentTime

            val trksegStringBuilder = StringBuilder()
            var maxSpeed = 0.0f // Max Speed 초기화

            for (location in locations) {
                val trkpt =
                    """<trkpt lat="${location.latitude}" lon="${location.longitude}"><time>${dateFormat.format(
                        Date(location.time)
                    )}</time><speed>${location.speed}</speed><ele>${location.altitude}</ele></trkpt>"""
                trksegStringBuilder.append(trkpt)

                // 최대 속도 갱신
                if (location.speed > maxSpeed) {
                    maxSpeed = location.speed
                }
            }

            val trkseg = """<trkseg>${trksegStringBuilder.toString()}</trkseg>"""

            val trk = """<trk><name>$currentTime</name>$trkseg</trk>"""

            val gpxContent = "<gpx version=\"$GPX_VERSION\" creator=\"$GPX_CREATOR\" xmlns=\"$GPX_NAMESPACE\" " +
                    "xmlns:xsi=\"$GPX_XSI_NAMESPACE\" xsi:schemaLocation=\"$GPX_NAMESPACE http://www.topografix.com/GPX/1/1/gpx.xsd\">" +
                    "$trk</gpx>"

            data.addStringToGPX(gpxContent)

            data.save(file)
        }

        // 나머지 함수들은 동일합니다.
    }
}
