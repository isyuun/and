package kr.carepet.data.cmm


import com.google.gson.annotations.SerializedName

class Data