package kr.carepet.data.user

//import androidx.compose.runtime.Composable
//import androidx.navigation.NavHostController
//import kr.carepet.screens.IdFindScreen
//import kr.carepet.screens.PwFindScreen
//import kr.carepet.viewmodel.IPFViewModel
//
//data class IDPWTabItem(
//    val title: String,
//    val screen: @Composable (NavHostController,IPFViewModel) -> Unit // navController를 매개변수로 추가
//)
//
//val IDPWTabItems = listOf(
//    IDPWTabItem(title = "아이디 찾기", screen = { navController, viewModel -> IdFindScreen(navController, viewModel) }),
//    IDPWTabItem(title = "비밀번호 찾기", screen = { navController, viewModel -> PwFindScreen(navController,viewModel) })
//)