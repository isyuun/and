package kr.carepet.service.app.navi.model

data class CommentData(
    val userId:String,
    val userProfile:Int,
    val comment:String
)
