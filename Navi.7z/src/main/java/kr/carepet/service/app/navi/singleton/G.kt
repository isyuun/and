package kr.carepet.service.app.navi.singleton

object G {
    var userId:String = ""
    var userEmail:String = ""

    var accessToken:String = ""
    var refreshToken:String = ""
}